
-- this file gets written automatically by the Archipelago Randomizer and is in its raw form a Jinja2 Template
require('lib')
data.raw["item"]["rocket-part"].hidden = false
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes = {
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { 0, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { 0, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, 0 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, 0 } }
        }
    },
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { -3, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { -3, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, -3 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, -3 } }
        }
    },
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { 3, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { 3, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, 3 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, 3 } }
        }
    }
}
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes_off_when_no_fluid_recipe = true
data.raw["recipe"]["rocket-part"].category = "rocket-building"
data.raw["recipe"]["rocket-part"].ingredients = {{type = "item", name = "flamethrower-turret", amount = 10},
{type = "item", name = "express-underground-belt", amount = 10},
{type = "item", name = "heat-exchanger", amount = 10}
}
data.raw["recipe"]["ap-energy-bridge"].category = "crafting"
data.raw["recipe"]["ap-energy-bridge"].ingredients = {{type = "item", name = "transport-belt", amount = 435},
{type = "item", name = "stone-brick", amount = 405},
{type = "item", name = "stone", amount = 85},
{type = "item", name = "pipe", amount = 336},
{type = "item", name = "iron-plate", amount = 140},
{type = "item", name = "iron-ore", amount = 354}
}

local technologies = data.raw["technology"]
local new_tree_copy

local template_tech = table.deepcopy(technologies["automation"])
template_tech.unlocks = {}
template_tech.upgrade = false
template_tech.effects = {}
template_tech.prerequisites = {}

function set_ap_icon(tech)
    tech.icon = "__AP-88872051018193305301-P2-Player2__/graphics/icons/ap.png"
    tech.icons = nil
    tech.icon_size = 128
end

function set_ap_unimportant_icon(tech)
    tech.icon = "__AP-88872051018193305301-P2-Player2__/graphics/icons/ap_unimportant.png"
    tech.icons = nil
    tech.icon_size = 128
end

function copy_factorio_icon(tech, tech_source)
    tech.icon = table.deepcopy(technologies[tech_source].icon)
    tech.icons = table.deepcopy(technologies[tech_source].icons)
    tech.icon_size = table.deepcopy(technologies[tech_source].icon_size)
end


function adjust_energy(recipe_name, factor)
    local recipe = data.raw.recipe[recipe_name]
    local energy = recipe.energy_required

    if (recipe.normal ~= nil) then
        if (recipe.normal.energy_required == nil) then
            energy = 0.5
        else
            energy = recipe.normal.energy_required
        end
        recipe.normal.energy_required = energy * factor
    end
    if (recipe.expensive ~= nil) then
        if (recipe.expensive.energy_required == nil) then
            energy = 0.5
        else
            energy = recipe.expensive.energy_required
        end
        recipe.expensive.energy_required = energy * factor
    end
    if (energy ~= nil) then
        data.raw.recipe[recipe_name].energy_required = energy * factor
    elseif (recipe.expensive == nil and recipe.normal == nil) then
        data.raw.recipe[recipe_name].energy_required = 0.5 * factor
    end
end

function set_energy(recipe_name, energy)
    local recipe = data.raw.recipe[recipe_name]

    if (recipe.normal ~= nil) then
        recipe.normal.energy_required = energy
    end
    if (recipe.expensive ~= nil) then
        recipe.expensive.energy_required = energy
    end
    if (recipe.expensive == nil and recipe.normal == nil) then
        recipe.energy_required = energy
    end
end

data.raw["assembling-machine"]["assembling-machine-1"].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
data.raw["assembling-machine"]["assembling-machine-2"].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
data.raw["assembling-machine"]["assembling-machine-1"].fluid_boxes = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes)
if mods["factory-levels"] then
    -- Factory-Levels allows the assembling machines to get faster (and depending on settings), more productive at crafting products, the more the
    -- assembling machine crafts the product.  If the machine crafts enough, it may auto-upgrade to the next tier.
    for i = 1, 25, 1 do
        data.raw["assembling-machine"]["assembling-machine-1-level-" .. i].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
        data.raw["assembling-machine"]["assembling-machine-1-level-" .. i].fluid_boxes = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes)
    end
    for i = 1, 50, 1 do
        data.raw["assembling-machine"]["assembling-machine-2-level-" .. i].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
    end
end

data.raw["ammo"]["artillery-shell"].stack_size = 10

technologies["advanced-circuit"].hidden = true
technologies["advanced-circuit"].hidden_in_factoriopedia = true
technologies["advanced-combinators"].hidden = true
technologies["advanced-combinators"].hidden_in_factoriopedia = true
technologies["advanced-material-processing"].hidden = true
technologies["advanced-material-processing"].hidden_in_factoriopedia = true
technologies["advanced-material-processing-2"].hidden = true
technologies["advanced-material-processing-2"].hidden_in_factoriopedia = true
technologies["advanced-oil-processing"].hidden = true
technologies["advanced-oil-processing"].hidden_in_factoriopedia = true
technologies["artillery"].hidden = true
technologies["artillery"].hidden_in_factoriopedia = true
technologies["atomic-bomb"].hidden = true
technologies["atomic-bomb"].hidden_in_factoriopedia = true
technologies["automated-rail-transportation"].hidden = true
technologies["automated-rail-transportation"].hidden_in_factoriopedia = true
technologies["automation"].hidden = true
technologies["automation"].hidden_in_factoriopedia = true
technologies["automation-2"].hidden = true
technologies["automation-2"].hidden_in_factoriopedia = true
technologies["automation-3"].hidden = true
technologies["automation-3"].hidden_in_factoriopedia = true
technologies["automation-science-pack"].hidden = true
technologies["automation-science-pack"].hidden_in_factoriopedia = true
technologies["automobilism"].hidden = true
technologies["automobilism"].hidden_in_factoriopedia = true
technologies["battery"].hidden = true
technologies["battery"].hidden_in_factoriopedia = true
technologies["battery-equipment"].hidden = true
technologies["battery-equipment"].hidden_in_factoriopedia = true
technologies["battery-mk2-equipment"].hidden = true
technologies["battery-mk2-equipment"].hidden_in_factoriopedia = true
technologies["belt-immunity-equipment"].hidden = true
technologies["belt-immunity-equipment"].hidden_in_factoriopedia = true
technologies["braking-force-1"].hidden = true
technologies["braking-force-1"].hidden_in_factoriopedia = true
technologies["braking-force-2"].hidden = true
technologies["braking-force-2"].hidden_in_factoriopedia = true
technologies["braking-force-3"].hidden = true
technologies["braking-force-3"].hidden_in_factoriopedia = true
technologies["braking-force-4"].hidden = true
technologies["braking-force-4"].hidden_in_factoriopedia = true
technologies["braking-force-5"].hidden = true
technologies["braking-force-5"].hidden_in_factoriopedia = true
technologies["braking-force-6"].hidden = true
technologies["braking-force-6"].hidden_in_factoriopedia = true
technologies["braking-force-7"].hidden = true
technologies["braking-force-7"].hidden_in_factoriopedia = true
technologies["bulk-inserter"].hidden = true
technologies["bulk-inserter"].hidden_in_factoriopedia = true
technologies["chemical-science-pack"].hidden = true
technologies["chemical-science-pack"].hidden_in_factoriopedia = true
technologies["circuit-network"].hidden = true
technologies["circuit-network"].hidden_in_factoriopedia = true
technologies["cliff-explosives"].hidden = true
technologies["cliff-explosives"].hidden_in_factoriopedia = true
technologies["coal-liquefaction"].hidden = true
technologies["coal-liquefaction"].hidden_in_factoriopedia = true
technologies["concrete"].hidden = true
technologies["concrete"].hidden_in_factoriopedia = true
technologies["construction-robotics"].hidden = true
technologies["construction-robotics"].hidden_in_factoriopedia = true
technologies["defender"].hidden = true
technologies["defender"].hidden_in_factoriopedia = true
technologies["destroyer"].hidden = true
technologies["destroyer"].hidden_in_factoriopedia = true
technologies["discharge-defense-equipment"].hidden = true
technologies["discharge-defense-equipment"].hidden_in_factoriopedia = true
technologies["distractor"].hidden = true
technologies["distractor"].hidden_in_factoriopedia = true
technologies["effect-transmission"].hidden = true
technologies["effect-transmission"].hidden_in_factoriopedia = true
technologies["efficiency-module"].hidden = true
technologies["efficiency-module"].hidden_in_factoriopedia = true
technologies["efficiency-module-2"].hidden = true
technologies["efficiency-module-2"].hidden_in_factoriopedia = true
technologies["efficiency-module-3"].hidden = true
technologies["efficiency-module-3"].hidden_in_factoriopedia = true
technologies["electric-energy-accumulators"].hidden = true
technologies["electric-energy-accumulators"].hidden_in_factoriopedia = true
technologies["electric-energy-distribution-1"].hidden = true
technologies["electric-energy-distribution-1"].hidden_in_factoriopedia = true
technologies["electric-energy-distribution-2"].hidden = true
technologies["electric-energy-distribution-2"].hidden_in_factoriopedia = true
technologies["electric-engine"].hidden = true
technologies["electric-engine"].hidden_in_factoriopedia = true
technologies["electric-mining-drill"].hidden = true
technologies["electric-mining-drill"].hidden_in_factoriopedia = true
technologies["electronics"].hidden = true
technologies["electronics"].hidden_in_factoriopedia = true
technologies["energy-shield-equipment"].hidden = true
technologies["energy-shield-equipment"].hidden_in_factoriopedia = true
technologies["energy-shield-mk2-equipment"].hidden = true
technologies["energy-shield-mk2-equipment"].hidden_in_factoriopedia = true
technologies["engine"].hidden = true
technologies["engine"].hidden_in_factoriopedia = true
technologies["exoskeleton-equipment"].hidden = true
technologies["exoskeleton-equipment"].hidden_in_factoriopedia = true
technologies["explosive-rocketry"].hidden = true
technologies["explosive-rocketry"].hidden_in_factoriopedia = true
technologies["explosives"].hidden = true
technologies["explosives"].hidden_in_factoriopedia = true
technologies["fast-inserter"].hidden = true
technologies["fast-inserter"].hidden_in_factoriopedia = true
technologies["fission-reactor-equipment"].hidden = true
technologies["fission-reactor-equipment"].hidden_in_factoriopedia = true
technologies["flamethrower"].hidden = true
technologies["flamethrower"].hidden_in_factoriopedia = true
technologies["flammables"].hidden = true
technologies["flammables"].hidden_in_factoriopedia = true
technologies["fluid-handling"].hidden = true
technologies["fluid-handling"].hidden_in_factoriopedia = true
technologies["fluid-wagon"].hidden = true
technologies["fluid-wagon"].hidden_in_factoriopedia = true
technologies["follower-robot-count-1"].hidden = true
technologies["follower-robot-count-1"].hidden_in_factoriopedia = true
technologies["follower-robot-count-2"].hidden = true
technologies["follower-robot-count-2"].hidden_in_factoriopedia = true
technologies["follower-robot-count-3"].hidden = true
technologies["follower-robot-count-3"].hidden_in_factoriopedia = true
technologies["follower-robot-count-4"].hidden = true
technologies["follower-robot-count-4"].hidden_in_factoriopedia = true
technologies["gate"].hidden = true
technologies["gate"].hidden_in_factoriopedia = true
technologies["gun-turret"].hidden = true
technologies["gun-turret"].hidden_in_factoriopedia = true
technologies["heavy-armor"].hidden = true
technologies["heavy-armor"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-1"].hidden = true
technologies["inserter-capacity-bonus-1"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-2"].hidden = true
technologies["inserter-capacity-bonus-2"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-3"].hidden = true
technologies["inserter-capacity-bonus-3"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-4"].hidden = true
technologies["inserter-capacity-bonus-4"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-5"].hidden = true
technologies["inserter-capacity-bonus-5"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-6"].hidden = true
technologies["inserter-capacity-bonus-6"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-7"].hidden = true
technologies["inserter-capacity-bonus-7"].hidden_in_factoriopedia = true
technologies["kovarex-enrichment-process"].hidden = true
technologies["kovarex-enrichment-process"].hidden_in_factoriopedia = true
technologies["lamp"].hidden = true
technologies["lamp"].hidden_in_factoriopedia = true
technologies["land-mine"].hidden = true
technologies["land-mine"].hidden_in_factoriopedia = true
technologies["landfill"].hidden = true
technologies["landfill"].hidden_in_factoriopedia = true
technologies["laser"].hidden = true
technologies["laser"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-1"].hidden = true
technologies["laser-shooting-speed-1"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-2"].hidden = true
technologies["laser-shooting-speed-2"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-3"].hidden = true
technologies["laser-shooting-speed-3"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-4"].hidden = true
technologies["laser-shooting-speed-4"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-5"].hidden = true
technologies["laser-shooting-speed-5"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-6"].hidden = true
technologies["laser-shooting-speed-6"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-7"].hidden = true
technologies["laser-shooting-speed-7"].hidden_in_factoriopedia = true
technologies["laser-turret"].hidden = true
technologies["laser-turret"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-1"].hidden = true
technologies["laser-weapons-damage-1"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-2"].hidden = true
technologies["laser-weapons-damage-2"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-3"].hidden = true
technologies["laser-weapons-damage-3"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-4"].hidden = true
technologies["laser-weapons-damage-4"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-5"].hidden = true
technologies["laser-weapons-damage-5"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-6"].hidden = true
technologies["laser-weapons-damage-6"].hidden_in_factoriopedia = true
technologies["logistic-robotics"].hidden = true
technologies["logistic-robotics"].hidden_in_factoriopedia = true
technologies["logistic-science-pack"].hidden = true
technologies["logistic-science-pack"].hidden_in_factoriopedia = true
technologies["logistic-system"].hidden = true
technologies["logistic-system"].hidden_in_factoriopedia = true
technologies["logistics"].hidden = true
technologies["logistics"].hidden_in_factoriopedia = true
technologies["logistics-2"].hidden = true
technologies["logistics-2"].hidden_in_factoriopedia = true
technologies["logistics-3"].hidden = true
technologies["logistics-3"].hidden_in_factoriopedia = true
technologies["low-density-structure"].hidden = true
technologies["low-density-structure"].hidden_in_factoriopedia = true
technologies["lubricant"].hidden = true
technologies["lubricant"].hidden_in_factoriopedia = true
technologies["military"].hidden = true
technologies["military"].hidden_in_factoriopedia = true
technologies["military-2"].hidden = true
technologies["military-2"].hidden_in_factoriopedia = true
technologies["military-3"].hidden = true
technologies["military-3"].hidden_in_factoriopedia = true
technologies["military-4"].hidden = true
technologies["military-4"].hidden_in_factoriopedia = true
technologies["military-science-pack"].hidden = true
technologies["military-science-pack"].hidden_in_factoriopedia = true
technologies["mining-productivity-1"].hidden = true
technologies["mining-productivity-1"].hidden_in_factoriopedia = true
technologies["mining-productivity-2"].hidden = true
technologies["mining-productivity-2"].hidden_in_factoriopedia = true
technologies["mining-productivity-3"].hidden = true
technologies["mining-productivity-3"].hidden_in_factoriopedia = true
technologies["modular-armor"].hidden = true
technologies["modular-armor"].hidden_in_factoriopedia = true
technologies["modules"].hidden = true
technologies["modules"].hidden_in_factoriopedia = true
technologies["night-vision-equipment"].hidden = true
technologies["night-vision-equipment"].hidden_in_factoriopedia = true
technologies["nuclear-fuel-reprocessing"].hidden = true
technologies["nuclear-fuel-reprocessing"].hidden_in_factoriopedia = true
technologies["nuclear-power"].hidden = true
technologies["nuclear-power"].hidden_in_factoriopedia = true
technologies["oil-gathering"].hidden = true
technologies["oil-gathering"].hidden_in_factoriopedia = true
technologies["oil-processing"].hidden = true
technologies["oil-processing"].hidden_in_factoriopedia = true
technologies["personal-laser-defense-equipment"].hidden = true
technologies["personal-laser-defense-equipment"].hidden_in_factoriopedia = true
technologies["personal-roboport-equipment"].hidden = true
technologies["personal-roboport-equipment"].hidden_in_factoriopedia = true
technologies["personal-roboport-mk2-equipment"].hidden = true
technologies["personal-roboport-mk2-equipment"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-1"].hidden = true
technologies["physical-projectile-damage-1"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-2"].hidden = true
technologies["physical-projectile-damage-2"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-3"].hidden = true
technologies["physical-projectile-damage-3"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-4"].hidden = true
technologies["physical-projectile-damage-4"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-5"].hidden = true
technologies["physical-projectile-damage-5"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-6"].hidden = true
technologies["physical-projectile-damage-6"].hidden_in_factoriopedia = true
technologies["plastics"].hidden = true
technologies["plastics"].hidden_in_factoriopedia = true
technologies["power-armor"].hidden = true
technologies["power-armor"].hidden_in_factoriopedia = true
technologies["power-armor-mk2"].hidden = true
technologies["power-armor-mk2"].hidden_in_factoriopedia = true
technologies["processing-unit"].hidden = true
technologies["processing-unit"].hidden_in_factoriopedia = true
technologies["production-science-pack"].hidden = true
technologies["production-science-pack"].hidden_in_factoriopedia = true
technologies["productivity-module"].hidden = true
technologies["productivity-module"].hidden_in_factoriopedia = true
technologies["productivity-module-2"].hidden = true
technologies["productivity-module-2"].hidden_in_factoriopedia = true
technologies["productivity-module-3"].hidden = true
technologies["productivity-module-3"].hidden_in_factoriopedia = true
technologies["radar"].hidden = true
technologies["radar"].hidden_in_factoriopedia = true
technologies["railway"].hidden = true
technologies["railway"].hidden_in_factoriopedia = true
technologies["refined-flammables-1"].hidden = true
technologies["refined-flammables-1"].hidden_in_factoriopedia = true
technologies["refined-flammables-2"].hidden = true
technologies["refined-flammables-2"].hidden_in_factoriopedia = true
technologies["refined-flammables-3"].hidden = true
technologies["refined-flammables-3"].hidden_in_factoriopedia = true
technologies["refined-flammables-4"].hidden = true
technologies["refined-flammables-4"].hidden_in_factoriopedia = true
technologies["refined-flammables-5"].hidden = true
technologies["refined-flammables-5"].hidden_in_factoriopedia = true
technologies["refined-flammables-6"].hidden = true
technologies["refined-flammables-6"].hidden_in_factoriopedia = true
technologies["repair-pack"].hidden = true
technologies["repair-pack"].hidden_in_factoriopedia = true
technologies["research-speed-1"].hidden = true
technologies["research-speed-1"].hidden_in_factoriopedia = true
technologies["research-speed-2"].hidden = true
technologies["research-speed-2"].hidden_in_factoriopedia = true
technologies["research-speed-3"].hidden = true
technologies["research-speed-3"].hidden_in_factoriopedia = true
technologies["research-speed-4"].hidden = true
technologies["research-speed-4"].hidden_in_factoriopedia = true
technologies["research-speed-5"].hidden = true
technologies["research-speed-5"].hidden_in_factoriopedia = true
technologies["research-speed-6"].hidden = true
technologies["research-speed-6"].hidden_in_factoriopedia = true
technologies["robotics"].hidden = true
technologies["robotics"].hidden_in_factoriopedia = true
technologies["rocket-fuel"].hidden = true
technologies["rocket-fuel"].hidden_in_factoriopedia = true
technologies["rocket-silo"].hidden = true
technologies["rocket-silo"].hidden_in_factoriopedia = true
technologies["rocketry"].hidden = true
technologies["rocketry"].hidden_in_factoriopedia = true
technologies["solar-energy"].hidden = true
technologies["solar-energy"].hidden_in_factoriopedia = true
technologies["solar-panel-equipment"].hidden = true
technologies["solar-panel-equipment"].hidden_in_factoriopedia = true
technologies["space-science-pack"].hidden = true
technologies["space-science-pack"].hidden_in_factoriopedia = true
technologies["speed-module"].hidden = true
technologies["speed-module"].hidden_in_factoriopedia = true
technologies["speed-module-2"].hidden = true
technologies["speed-module-2"].hidden_in_factoriopedia = true
technologies["speed-module-3"].hidden = true
technologies["speed-module-3"].hidden_in_factoriopedia = true
technologies["spidertron"].hidden = true
technologies["spidertron"].hidden_in_factoriopedia = true
technologies["steam-power"].hidden = true
technologies["steam-power"].hidden_in_factoriopedia = true
technologies["steel-axe"].hidden = true
technologies["steel-axe"].hidden_in_factoriopedia = true
technologies["steel-processing"].hidden = true
technologies["steel-processing"].hidden_in_factoriopedia = true
technologies["stone-wall"].hidden = true
technologies["stone-wall"].hidden_in_factoriopedia = true
technologies["stronger-explosives-1"].hidden = true
technologies["stronger-explosives-1"].hidden_in_factoriopedia = true
technologies["stronger-explosives-2"].hidden = true
technologies["stronger-explosives-2"].hidden_in_factoriopedia = true
technologies["stronger-explosives-3"].hidden = true
technologies["stronger-explosives-3"].hidden_in_factoriopedia = true
technologies["stronger-explosives-4"].hidden = true
technologies["stronger-explosives-4"].hidden_in_factoriopedia = true
technologies["stronger-explosives-5"].hidden = true
technologies["stronger-explosives-5"].hidden_in_factoriopedia = true
technologies["stronger-explosives-6"].hidden = true
technologies["stronger-explosives-6"].hidden_in_factoriopedia = true
technologies["sulfur-processing"].hidden = true
technologies["sulfur-processing"].hidden_in_factoriopedia = true
technologies["tank"].hidden = true
technologies["tank"].hidden_in_factoriopedia = true
technologies["toolbelt"].hidden = true
technologies["toolbelt"].hidden_in_factoriopedia = true
technologies["uranium-ammo"].hidden = true
technologies["uranium-ammo"].hidden_in_factoriopedia = true
technologies["uranium-mining"].hidden = true
technologies["uranium-mining"].hidden_in_factoriopedia = true
technologies["uranium-processing"].hidden = true
technologies["uranium-processing"].hidden_in_factoriopedia = true
technologies["utility-science-pack"].hidden = true
technologies["utility-science-pack"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-1"].hidden = true
technologies["weapon-shooting-speed-1"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-2"].hidden = true
technologies["weapon-shooting-speed-2"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-3"].hidden = true
technologies["weapon-shooting-speed-3"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-4"].hidden = true
technologies["weapon-shooting-speed-4"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-5"].hidden = true
technologies["weapon-shooting-speed-5"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-6"].hidden = true
technologies["weapon-shooting-speed-6"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-1"].hidden = true
technologies["worker-robots-speed-1"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-2"].hidden = true
technologies["worker-robots-speed-2"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-3"].hidden = true
technologies["worker-robots-speed-3"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-4"].hidden = true
technologies["worker-robots-speed-4"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-5"].hidden = true
technologies["worker-robots-speed-5"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-1"].hidden = true
technologies["worker-robots-storage-1"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-2"].hidden = true
technologies["worker-robots-storage-2"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-3"].hidden = true
technologies["worker-robots-storage-3"].hidden_in_factoriopedia = true

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136234-"
new_tree_copy.unit.count = 81
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131998-"
new_tree_copy.unit.count = 476
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132850-"
new_tree_copy.unit.count = 394
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "toolbelt")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131283-"
new_tree_copy.unit.count = 107
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "toolbelt")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132283-"
new_tree_copy.unit.count = 108
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134197-"
new_tree_copy.unit.count = 68
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136687-"
new_tree_copy.unit.count = 323
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fluid-handling")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136503-"
new_tree_copy.unit.count = 216
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "solar-energy")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136296-"
new_tree_copy.unit.count = 114
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "construction-robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135468-"
new_tree_copy.unit.count = 204
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "energy-shield-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132688-"
new_tree_copy.unit.count = 311
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-system")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134263-"
new_tree_copy.unit.count = 85
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132042-"
new_tree_copy.unit.count = 488
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136391-"
new_tree_copy.unit.count = 161
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135299-"
new_tree_copy.unit.count = 115
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "solar-panel-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131470-"
new_tree_copy.unit.count = 200
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135292-"
new_tree_copy.unit.count = 110
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136631-"
new_tree_copy.unit.count = 290
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136186-"
new_tree_copy.unit.count = 64
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "personal-roboport-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135515-"
new_tree_copy.unit.count = 234
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "lubricant")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135622-"
new_tree_copy.unit.count = 280
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134164-"
new_tree_copy.unit.count = 52
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136666-"
new_tree_copy.unit.count = 304
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "nuclear-power")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132348-"
new_tree_copy.unit.count = 131
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135066-"
new_tree_copy.unit.count = 499
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133789-"
new_tree_copy.unit.count = 349
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "battery")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134268-"
new_tree_copy.unit.count = 99
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136426-"
new_tree_copy.unit.count = 183
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132836-"
new_tree_copy.unit.count = 388
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "engine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134821-"
new_tree_copy.unit.count = 384
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133882-"
new_tree_copy.unit.count = 429
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134572-"
new_tree_copy.unit.count = 254
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132249-"
new_tree_copy.unit.count = 84
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132497-"
new_tree_copy.unit.count = 214
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135916-"
new_tree_copy.unit.count = 445
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135040-"
new_tree_copy.unit.count = 491
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131963-"
new_tree_copy.unit.count = 459
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132080-"
new_tree_copy.unit.count = 13
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134098-"
new_tree_copy.unit.count = 15
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136867-"
new_tree_copy.unit.count = 422
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "lamp")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131450-"
new_tree_copy.unit.count = 191
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stone-wall")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133977-"
new_tree_copy.unit.count = 464
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136458-"
new_tree_copy.unit.count = 192
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133142-"
new_tree_copy.unit.count = 50
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "gun-turret")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135686-"
new_tree_copy.unit.count = 323
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131528-"
new_tree_copy.unit.count = 239
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "gun-turret")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134692-"
new_tree_copy.unit.count = 324
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136407-"
new_tree_copy.unit.count = 164
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136604-"
new_tree_copy.unit.count = 275
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "energy-shield-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133722-"
new_tree_copy.unit.count = 327
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132257-"
new_tree_copy.unit.count = 84
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "lubricant")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136071-"
new_tree_copy.unit.count = 7
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "low-density-structure")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134609-"
new_tree_copy.unit.count = 279
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "advanced-material-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134677-"
new_tree_copy.unit.count = 305
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "uranium-mining")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131829-"
new_tree_copy.unit.count = 384
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fission-reactor-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135572-"
new_tree_copy.unit.count = 256
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136960-"
new_tree_copy.unit.count = 463
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "landfill")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134176-"
new_tree_copy.unit.count = 55
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "advanced-material-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133322-"
new_tree_copy.unit.count = 120
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "plastics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135585-"
new_tree_copy.unit.count = 271
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "nuclear-power")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132863-"
new_tree_copy.unit.count = 404
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stone-wall")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131403-"
new_tree_copy.unit.count = 162
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131478-"
new_tree_copy.unit.count = 208
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131724-"
new_tree_copy.unit.count = 329
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134872-"
new_tree_copy.unit.count = 426
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "electric-energy-accumulators")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135381-"
new_tree_copy.unit.count = 146
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136488-"
new_tree_copy.unit.count = 212
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131655-"
new_tree_copy.unit.count = 300
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "radar")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133386-"
new_tree_copy.unit.count = 155
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131191-"
new_tree_copy.unit.count = 10
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132472-"
new_tree_copy.unit.count = 205
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "belt-immunity-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131820-"
new_tree_copy.unit.count = 379
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134654-"
new_tree_copy.unit.count = 304
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134414-"
new_tree_copy.unit.count = 166
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135365-"
new_tree_copy.unit.count = 137
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135677-"
new_tree_copy.unit.count = 308
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132406-"
new_tree_copy.unit.count = 163
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134708-"
new_tree_copy.unit.count = 327
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132465-"
new_tree_copy.unit.count = 200
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133987-"
new_tree_copy.unit.count = 472
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131426-"
new_tree_copy.unit.count = 167
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "battery-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134343-"
new_tree_copy.unit.count = 124
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135459-"
new_tree_copy.unit.count = 192
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133833-"
new_tree_copy.unit.count = 388
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134391-"
new_tree_copy.unit.count = 160
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "uranium-ammo")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131841-"
new_tree_copy.unit.count = 389
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "advanced-circuit")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131866-"
new_tree_copy.unit.count = 418
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132632-"
new_tree_copy.unit.count = 283
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135348-"
new_tree_copy.unit.count = 132
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135926-"
new_tree_copy.unit.count = 451
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135542-"
new_tree_copy.unit.count = 247
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136226-"
new_tree_copy.unit.count = 76
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "belt-immunity-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133577-"
new_tree_copy.unit.count = 261
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131373-"
new_tree_copy.unit.count = 138
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136797-"
new_tree_copy.unit.count = 367
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "exoskeleton-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133829-"
new_tree_copy.unit.count = 387
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133241-"
new_tree_copy.unit.count = 83
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133459-"
new_tree_copy.unit.count = 192
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131959-"
new_tree_copy.unit.count = 455
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134679-"
new_tree_copy.unit.count = 310
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "personal-laser-defense-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136571-"
new_tree_copy.unit.count = 257
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stone-wall")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134554-"
new_tree_copy.unit.count = 251
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136760-"
new_tree_copy.unit.count = 342
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133747-"
new_tree_copy.unit.count = 337
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "solar-panel-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136907-"
new_tree_copy.unit.count = 444
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132730-"
new_tree_copy.unit.count = 331
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "battery-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-137031-"
new_tree_copy.unit.count = 483
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "rocket-silo")
table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 1: flamethrower-turret"})

table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 2: express-underground-belt"})

table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 3: heat-exchanger"})

data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136752-"
new_tree_copy.unit.count = 342
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133444-"
new_tree_copy.unit.count = 185
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135508-"
new_tree_copy.unit.count = 218
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134358-"
new_tree_copy.unit.count = 136
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133781-"
new_tree_copy.unit.count = 348
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "concrete")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134874-"
new_tree_copy.unit.count = 428
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133390-"
new_tree_copy.unit.count = 159
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "advanced-material-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135951-"
new_tree_copy.unit.count = 454
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136547-"
new_tree_copy.unit.count = 249
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "electric-energy-accumulators")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134729-"
new_tree_copy.unit.count = 332
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133080-"
new_tree_copy.unit.count = 15
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131780-"
new_tree_copy.unit.count = 347
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "rocket-fuel")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132905-"
new_tree_copy.unit.count = 442
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "effect-transmission")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135101-"
new_tree_copy.unit.count = 20
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134370-"
new_tree_copy.unit.count = 138
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135579-"
new_tree_copy.unit.count = 265
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134150-"
new_tree_copy.unit.count = 50
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134860-"
new_tree_copy.unit.count = 397
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "engine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136384-"
new_tree_copy.unit.count = 155
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132200-"
new_tree_copy.unit.count = 68
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "concrete")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136293-"
new_tree_copy.unit.count = 110
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "radar")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136275-"
new_tree_copy.unit.count = 106
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133800-"
new_tree_copy.unit.count = 370
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134926-"
new_tree_copy.unit.count = 447
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "battery-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136516-"
new_tree_copy.unit.count = 235
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136539-"
new_tree_copy.unit.count = 247
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132052-"
new_tree_copy.unit.count = 498
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132286-"
new_tree_copy.unit.count = 108
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136316-"
new_tree_copy.unit.count = 117
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136955-"
new_tree_copy.unit.count = 457
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134133-"
new_tree_copy.unit.count = 41
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134026-"
new_tree_copy.unit.count = 482
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "processing-unit")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134942-"
new_tree_copy.unit.count = 452
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136633-"
new_tree_copy.unit.count = 292
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "advanced-combinators")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132388-"
new_tree_copy.unit.count = 157
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131983-"
new_tree_copy.unit.count = 468
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133132-"
new_tree_copy.unit.count = 36
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131247-"
new_tree_copy.unit.count = 10
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135531-"
new_tree_copy.unit.count = 243
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132798-"
new_tree_copy.unit.count = 365
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135117-"
new_tree_copy.unit.count = 26
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131989-"
new_tree_copy.unit.count = 474
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132001-"
new_tree_copy.unit.count = 477
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136793-"
new_tree_copy.unit.count = 359
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131376-"
new_tree_copy.unit.count = 138
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136510-"
new_tree_copy.unit.count = 234
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131339-"
new_tree_copy.unit.count = 123
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135742-"
new_tree_copy.unit.count = 334
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136201-"
new_tree_copy.unit.count = 69
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133646-"
new_tree_copy.unit.count = 300
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "construction-robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134536-"
new_tree_copy.unit.count = 244
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131643-"
new_tree_copy.unit.count = 299
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134509-"
new_tree_copy.unit.count = 233
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136446-"
new_tree_copy.unit.count = 191
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133360-"
new_tree_copy.unit.count = 136
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135567-"
new_tree_copy.unit.count = 252
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132979-"
new_tree_copy.unit.count = 466
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131323-"
new_tree_copy.unit.count = 118
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "oil-gathering")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136635-"
new_tree_copy.unit.count = 293
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "energy-shield-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131884-"
new_tree_copy.unit.count = 439
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132864-"
new_tree_copy.unit.count = 411
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134525-"
new_tree_copy.unit.count = 241
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136688-"
new_tree_copy.unit.count = 323
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131796-"
new_tree_copy.unit.count = 351
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135837-"
new_tree_copy.unit.count = 392
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "engine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132181-"
new_tree_copy.unit.count = 58
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136600-"
new_tree_copy.unit.count = 274
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135126-"
new_tree_copy.unit.count = 33
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "electric-energy-distribution-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132488-"
new_tree_copy.unit.count = 210
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "effect-transmission")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132278-"
new_tree_copy.unit.count = 103
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134743-"
new_tree_copy.unit.count = 337
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "explosives")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132109-"
new_tree_copy.unit.count = 22
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "night-vision-equipment")
data:extend{new_tree_copy}

