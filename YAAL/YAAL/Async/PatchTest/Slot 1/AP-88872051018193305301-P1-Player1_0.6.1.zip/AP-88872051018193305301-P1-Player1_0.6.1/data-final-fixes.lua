
-- this file gets written automatically by the Archipelago Randomizer and is in its raw form a Jinja2 Template
require('lib')
data.raw["item"]["rocket-part"].hidden = false
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes = {
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { 0, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { 0, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, 0 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, 0 } }
        }
    },
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { -3, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { -3, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, -3 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, -3 } }
        }
    },
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { 3, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { 3, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, 3 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, 3 } }
        }
    }
}
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes_off_when_no_fluid_recipe = true
data.raw["recipe"]["rocket-part"].category = "rocket-building"
data.raw["recipe"]["rocket-part"].ingredients = {{type = "item", name = "flamethrower-turret", amount = 10},
{type = "item", name = "heat-exchanger", amount = 10},
{type = "item", name = "steam-turbine", amount = 10}
}
data.raw["recipe"]["ap-energy-bridge"].category = "crafting"
data.raw["recipe"]["ap-energy-bridge"].ingredients = {{type = "item", name = "transport-belt", amount = 221},
{type = "item", name = "stone-brick", amount = 325},
{type = "item", name = "stone", amount = 281},
{type = "item", name = "pipe", amount = 492},
{type = "item", name = "iron-plate", amount = 330},
{type = "item", name = "iron-ore", amount = 435}
}

local technologies = data.raw["technology"]
local new_tree_copy

local template_tech = table.deepcopy(technologies["automation"])
template_tech.unlocks = {}
template_tech.upgrade = false
template_tech.effects = {}
template_tech.prerequisites = {}

function set_ap_icon(tech)
    tech.icon = "__AP-88872051018193305301-P1-Player1__/graphics/icons/ap.png"
    tech.icons = nil
    tech.icon_size = 128
end

function set_ap_unimportant_icon(tech)
    tech.icon = "__AP-88872051018193305301-P1-Player1__/graphics/icons/ap_unimportant.png"
    tech.icons = nil
    tech.icon_size = 128
end

function copy_factorio_icon(tech, tech_source)
    tech.icon = table.deepcopy(technologies[tech_source].icon)
    tech.icons = table.deepcopy(technologies[tech_source].icons)
    tech.icon_size = table.deepcopy(technologies[tech_source].icon_size)
end


function adjust_energy(recipe_name, factor)
    local recipe = data.raw.recipe[recipe_name]
    local energy = recipe.energy_required

    if (recipe.normal ~= nil) then
        if (recipe.normal.energy_required == nil) then
            energy = 0.5
        else
            energy = recipe.normal.energy_required
        end
        recipe.normal.energy_required = energy * factor
    end
    if (recipe.expensive ~= nil) then
        if (recipe.expensive.energy_required == nil) then
            energy = 0.5
        else
            energy = recipe.expensive.energy_required
        end
        recipe.expensive.energy_required = energy * factor
    end
    if (energy ~= nil) then
        data.raw.recipe[recipe_name].energy_required = energy * factor
    elseif (recipe.expensive == nil and recipe.normal == nil) then
        data.raw.recipe[recipe_name].energy_required = 0.5 * factor
    end
end

function set_energy(recipe_name, energy)
    local recipe = data.raw.recipe[recipe_name]

    if (recipe.normal ~= nil) then
        recipe.normal.energy_required = energy
    end
    if (recipe.expensive ~= nil) then
        recipe.expensive.energy_required = energy
    end
    if (recipe.expensive == nil and recipe.normal == nil) then
        recipe.energy_required = energy
    end
end

data.raw["assembling-machine"]["assembling-machine-1"].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
data.raw["assembling-machine"]["assembling-machine-2"].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
data.raw["assembling-machine"]["assembling-machine-1"].fluid_boxes = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes)
if mods["factory-levels"] then
    -- Factory-Levels allows the assembling machines to get faster (and depending on settings), more productive at crafting products, the more the
    -- assembling machine crafts the product.  If the machine crafts enough, it may auto-upgrade to the next tier.
    for i = 1, 25, 1 do
        data.raw["assembling-machine"]["assembling-machine-1-level-" .. i].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
        data.raw["assembling-machine"]["assembling-machine-1-level-" .. i].fluid_boxes = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes)
    end
    for i = 1, 50, 1 do
        data.raw["assembling-machine"]["assembling-machine-2-level-" .. i].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
    end
end

data.raw["ammo"]["artillery-shell"].stack_size = 10

technologies["advanced-circuit"].hidden = true
technologies["advanced-circuit"].hidden_in_factoriopedia = true
technologies["advanced-combinators"].hidden = true
technologies["advanced-combinators"].hidden_in_factoriopedia = true
technologies["advanced-material-processing"].hidden = true
technologies["advanced-material-processing"].hidden_in_factoriopedia = true
technologies["advanced-material-processing-2"].hidden = true
technologies["advanced-material-processing-2"].hidden_in_factoriopedia = true
technologies["advanced-oil-processing"].hidden = true
technologies["advanced-oil-processing"].hidden_in_factoriopedia = true
technologies["artillery"].hidden = true
technologies["artillery"].hidden_in_factoriopedia = true
technologies["atomic-bomb"].hidden = true
technologies["atomic-bomb"].hidden_in_factoriopedia = true
technologies["automated-rail-transportation"].hidden = true
technologies["automated-rail-transportation"].hidden_in_factoriopedia = true
technologies["automation"].hidden = true
technologies["automation"].hidden_in_factoriopedia = true
technologies["automation-2"].hidden = true
technologies["automation-2"].hidden_in_factoriopedia = true
technologies["automation-3"].hidden = true
technologies["automation-3"].hidden_in_factoriopedia = true
technologies["automation-science-pack"].hidden = true
technologies["automation-science-pack"].hidden_in_factoriopedia = true
technologies["automobilism"].hidden = true
technologies["automobilism"].hidden_in_factoriopedia = true
technologies["battery"].hidden = true
technologies["battery"].hidden_in_factoriopedia = true
technologies["battery-equipment"].hidden = true
technologies["battery-equipment"].hidden_in_factoriopedia = true
technologies["battery-mk2-equipment"].hidden = true
technologies["battery-mk2-equipment"].hidden_in_factoriopedia = true
technologies["belt-immunity-equipment"].hidden = true
technologies["belt-immunity-equipment"].hidden_in_factoriopedia = true
technologies["braking-force-1"].hidden = true
technologies["braking-force-1"].hidden_in_factoriopedia = true
technologies["braking-force-2"].hidden = true
technologies["braking-force-2"].hidden_in_factoriopedia = true
technologies["braking-force-3"].hidden = true
technologies["braking-force-3"].hidden_in_factoriopedia = true
technologies["braking-force-4"].hidden = true
technologies["braking-force-4"].hidden_in_factoriopedia = true
technologies["braking-force-5"].hidden = true
technologies["braking-force-5"].hidden_in_factoriopedia = true
technologies["braking-force-6"].hidden = true
technologies["braking-force-6"].hidden_in_factoriopedia = true
technologies["braking-force-7"].hidden = true
technologies["braking-force-7"].hidden_in_factoriopedia = true
technologies["bulk-inserter"].hidden = true
technologies["bulk-inserter"].hidden_in_factoriopedia = true
technologies["chemical-science-pack"].hidden = true
technologies["chemical-science-pack"].hidden_in_factoriopedia = true
technologies["circuit-network"].hidden = true
technologies["circuit-network"].hidden_in_factoriopedia = true
technologies["cliff-explosives"].hidden = true
technologies["cliff-explosives"].hidden_in_factoriopedia = true
technologies["coal-liquefaction"].hidden = true
technologies["coal-liquefaction"].hidden_in_factoriopedia = true
technologies["concrete"].hidden = true
technologies["concrete"].hidden_in_factoriopedia = true
technologies["construction-robotics"].hidden = true
technologies["construction-robotics"].hidden_in_factoriopedia = true
technologies["defender"].hidden = true
technologies["defender"].hidden_in_factoriopedia = true
technologies["destroyer"].hidden = true
technologies["destroyer"].hidden_in_factoriopedia = true
technologies["discharge-defense-equipment"].hidden = true
technologies["discharge-defense-equipment"].hidden_in_factoriopedia = true
technologies["distractor"].hidden = true
technologies["distractor"].hidden_in_factoriopedia = true
technologies["effect-transmission"].hidden = true
technologies["effect-transmission"].hidden_in_factoriopedia = true
technologies["efficiency-module"].hidden = true
technologies["efficiency-module"].hidden_in_factoriopedia = true
technologies["efficiency-module-2"].hidden = true
technologies["efficiency-module-2"].hidden_in_factoriopedia = true
technologies["efficiency-module-3"].hidden = true
technologies["efficiency-module-3"].hidden_in_factoriopedia = true
technologies["electric-energy-accumulators"].hidden = true
technologies["electric-energy-accumulators"].hidden_in_factoriopedia = true
technologies["electric-energy-distribution-1"].hidden = true
technologies["electric-energy-distribution-1"].hidden_in_factoriopedia = true
technologies["electric-energy-distribution-2"].hidden = true
technologies["electric-energy-distribution-2"].hidden_in_factoriopedia = true
technologies["electric-engine"].hidden = true
technologies["electric-engine"].hidden_in_factoriopedia = true
technologies["electric-mining-drill"].hidden = true
technologies["electric-mining-drill"].hidden_in_factoriopedia = true
technologies["electronics"].hidden = true
technologies["electronics"].hidden_in_factoriopedia = true
technologies["energy-shield-equipment"].hidden = true
technologies["energy-shield-equipment"].hidden_in_factoriopedia = true
technologies["energy-shield-mk2-equipment"].hidden = true
technologies["energy-shield-mk2-equipment"].hidden_in_factoriopedia = true
technologies["engine"].hidden = true
technologies["engine"].hidden_in_factoriopedia = true
technologies["exoskeleton-equipment"].hidden = true
technologies["exoskeleton-equipment"].hidden_in_factoriopedia = true
technologies["explosive-rocketry"].hidden = true
technologies["explosive-rocketry"].hidden_in_factoriopedia = true
technologies["explosives"].hidden = true
technologies["explosives"].hidden_in_factoriopedia = true
technologies["fast-inserter"].hidden = true
technologies["fast-inserter"].hidden_in_factoriopedia = true
technologies["fission-reactor-equipment"].hidden = true
technologies["fission-reactor-equipment"].hidden_in_factoriopedia = true
technologies["flamethrower"].hidden = true
technologies["flamethrower"].hidden_in_factoriopedia = true
technologies["flammables"].hidden = true
technologies["flammables"].hidden_in_factoriopedia = true
technologies["fluid-handling"].hidden = true
technologies["fluid-handling"].hidden_in_factoriopedia = true
technologies["fluid-wagon"].hidden = true
technologies["fluid-wagon"].hidden_in_factoriopedia = true
technologies["follower-robot-count-1"].hidden = true
technologies["follower-robot-count-1"].hidden_in_factoriopedia = true
technologies["follower-robot-count-2"].hidden = true
technologies["follower-robot-count-2"].hidden_in_factoriopedia = true
technologies["follower-robot-count-3"].hidden = true
technologies["follower-robot-count-3"].hidden_in_factoriopedia = true
technologies["follower-robot-count-4"].hidden = true
technologies["follower-robot-count-4"].hidden_in_factoriopedia = true
technologies["gate"].hidden = true
technologies["gate"].hidden_in_factoriopedia = true
technologies["gun-turret"].hidden = true
technologies["gun-turret"].hidden_in_factoriopedia = true
technologies["heavy-armor"].hidden = true
technologies["heavy-armor"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-1"].hidden = true
technologies["inserter-capacity-bonus-1"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-2"].hidden = true
technologies["inserter-capacity-bonus-2"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-3"].hidden = true
technologies["inserter-capacity-bonus-3"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-4"].hidden = true
technologies["inserter-capacity-bonus-4"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-5"].hidden = true
technologies["inserter-capacity-bonus-5"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-6"].hidden = true
technologies["inserter-capacity-bonus-6"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-7"].hidden = true
technologies["inserter-capacity-bonus-7"].hidden_in_factoriopedia = true
technologies["kovarex-enrichment-process"].hidden = true
technologies["kovarex-enrichment-process"].hidden_in_factoriopedia = true
technologies["lamp"].hidden = true
technologies["lamp"].hidden_in_factoriopedia = true
technologies["land-mine"].hidden = true
technologies["land-mine"].hidden_in_factoriopedia = true
technologies["landfill"].hidden = true
technologies["landfill"].hidden_in_factoriopedia = true
technologies["laser"].hidden = true
technologies["laser"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-1"].hidden = true
technologies["laser-shooting-speed-1"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-2"].hidden = true
technologies["laser-shooting-speed-2"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-3"].hidden = true
technologies["laser-shooting-speed-3"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-4"].hidden = true
technologies["laser-shooting-speed-4"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-5"].hidden = true
technologies["laser-shooting-speed-5"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-6"].hidden = true
technologies["laser-shooting-speed-6"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-7"].hidden = true
technologies["laser-shooting-speed-7"].hidden_in_factoriopedia = true
technologies["laser-turret"].hidden = true
technologies["laser-turret"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-1"].hidden = true
technologies["laser-weapons-damage-1"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-2"].hidden = true
technologies["laser-weapons-damage-2"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-3"].hidden = true
technologies["laser-weapons-damage-3"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-4"].hidden = true
technologies["laser-weapons-damage-4"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-5"].hidden = true
technologies["laser-weapons-damage-5"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-6"].hidden = true
technologies["laser-weapons-damage-6"].hidden_in_factoriopedia = true
technologies["logistic-robotics"].hidden = true
technologies["logistic-robotics"].hidden_in_factoriopedia = true
technologies["logistic-science-pack"].hidden = true
technologies["logistic-science-pack"].hidden_in_factoriopedia = true
technologies["logistic-system"].hidden = true
technologies["logistic-system"].hidden_in_factoriopedia = true
technologies["logistics"].hidden = true
technologies["logistics"].hidden_in_factoriopedia = true
technologies["logistics-2"].hidden = true
technologies["logistics-2"].hidden_in_factoriopedia = true
technologies["logistics-3"].hidden = true
technologies["logistics-3"].hidden_in_factoriopedia = true
technologies["low-density-structure"].hidden = true
technologies["low-density-structure"].hidden_in_factoriopedia = true
technologies["lubricant"].hidden = true
technologies["lubricant"].hidden_in_factoriopedia = true
technologies["military"].hidden = true
technologies["military"].hidden_in_factoriopedia = true
technologies["military-2"].hidden = true
technologies["military-2"].hidden_in_factoriopedia = true
technologies["military-3"].hidden = true
technologies["military-3"].hidden_in_factoriopedia = true
technologies["military-4"].hidden = true
technologies["military-4"].hidden_in_factoriopedia = true
technologies["military-science-pack"].hidden = true
technologies["military-science-pack"].hidden_in_factoriopedia = true
technologies["mining-productivity-1"].hidden = true
technologies["mining-productivity-1"].hidden_in_factoriopedia = true
technologies["mining-productivity-2"].hidden = true
technologies["mining-productivity-2"].hidden_in_factoriopedia = true
technologies["mining-productivity-3"].hidden = true
technologies["mining-productivity-3"].hidden_in_factoriopedia = true
technologies["modular-armor"].hidden = true
technologies["modular-armor"].hidden_in_factoriopedia = true
technologies["modules"].hidden = true
technologies["modules"].hidden_in_factoriopedia = true
technologies["night-vision-equipment"].hidden = true
technologies["night-vision-equipment"].hidden_in_factoriopedia = true
technologies["nuclear-fuel-reprocessing"].hidden = true
technologies["nuclear-fuel-reprocessing"].hidden_in_factoriopedia = true
technologies["nuclear-power"].hidden = true
technologies["nuclear-power"].hidden_in_factoriopedia = true
technologies["oil-gathering"].hidden = true
technologies["oil-gathering"].hidden_in_factoriopedia = true
technologies["oil-processing"].hidden = true
technologies["oil-processing"].hidden_in_factoriopedia = true
technologies["personal-laser-defense-equipment"].hidden = true
technologies["personal-laser-defense-equipment"].hidden_in_factoriopedia = true
technologies["personal-roboport-equipment"].hidden = true
technologies["personal-roboport-equipment"].hidden_in_factoriopedia = true
technologies["personal-roboport-mk2-equipment"].hidden = true
technologies["personal-roboport-mk2-equipment"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-1"].hidden = true
technologies["physical-projectile-damage-1"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-2"].hidden = true
technologies["physical-projectile-damage-2"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-3"].hidden = true
technologies["physical-projectile-damage-3"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-4"].hidden = true
technologies["physical-projectile-damage-4"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-5"].hidden = true
technologies["physical-projectile-damage-5"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-6"].hidden = true
technologies["physical-projectile-damage-6"].hidden_in_factoriopedia = true
technologies["plastics"].hidden = true
technologies["plastics"].hidden_in_factoriopedia = true
technologies["power-armor"].hidden = true
technologies["power-armor"].hidden_in_factoriopedia = true
technologies["power-armor-mk2"].hidden = true
technologies["power-armor-mk2"].hidden_in_factoriopedia = true
technologies["processing-unit"].hidden = true
technologies["processing-unit"].hidden_in_factoriopedia = true
technologies["production-science-pack"].hidden = true
technologies["production-science-pack"].hidden_in_factoriopedia = true
technologies["productivity-module"].hidden = true
technologies["productivity-module"].hidden_in_factoriopedia = true
technologies["productivity-module-2"].hidden = true
technologies["productivity-module-2"].hidden_in_factoriopedia = true
technologies["productivity-module-3"].hidden = true
technologies["productivity-module-3"].hidden_in_factoriopedia = true
technologies["radar"].hidden = true
technologies["radar"].hidden_in_factoriopedia = true
technologies["railway"].hidden = true
technologies["railway"].hidden_in_factoriopedia = true
technologies["refined-flammables-1"].hidden = true
technologies["refined-flammables-1"].hidden_in_factoriopedia = true
technologies["refined-flammables-2"].hidden = true
technologies["refined-flammables-2"].hidden_in_factoriopedia = true
technologies["refined-flammables-3"].hidden = true
technologies["refined-flammables-3"].hidden_in_factoriopedia = true
technologies["refined-flammables-4"].hidden = true
technologies["refined-flammables-4"].hidden_in_factoriopedia = true
technologies["refined-flammables-5"].hidden = true
technologies["refined-flammables-5"].hidden_in_factoriopedia = true
technologies["refined-flammables-6"].hidden = true
technologies["refined-flammables-6"].hidden_in_factoriopedia = true
technologies["repair-pack"].hidden = true
technologies["repair-pack"].hidden_in_factoriopedia = true
technologies["research-speed-1"].hidden = true
technologies["research-speed-1"].hidden_in_factoriopedia = true
technologies["research-speed-2"].hidden = true
technologies["research-speed-2"].hidden_in_factoriopedia = true
technologies["research-speed-3"].hidden = true
technologies["research-speed-3"].hidden_in_factoriopedia = true
technologies["research-speed-4"].hidden = true
technologies["research-speed-4"].hidden_in_factoriopedia = true
technologies["research-speed-5"].hidden = true
technologies["research-speed-5"].hidden_in_factoriopedia = true
technologies["research-speed-6"].hidden = true
technologies["research-speed-6"].hidden_in_factoriopedia = true
technologies["robotics"].hidden = true
technologies["robotics"].hidden_in_factoriopedia = true
technologies["rocket-fuel"].hidden = true
technologies["rocket-fuel"].hidden_in_factoriopedia = true
technologies["rocket-silo"].hidden = true
technologies["rocket-silo"].hidden_in_factoriopedia = true
technologies["rocketry"].hidden = true
technologies["rocketry"].hidden_in_factoriopedia = true
technologies["solar-energy"].hidden = true
technologies["solar-energy"].hidden_in_factoriopedia = true
technologies["solar-panel-equipment"].hidden = true
technologies["solar-panel-equipment"].hidden_in_factoriopedia = true
technologies["space-science-pack"].hidden = true
technologies["space-science-pack"].hidden_in_factoriopedia = true
technologies["speed-module"].hidden = true
technologies["speed-module"].hidden_in_factoriopedia = true
technologies["speed-module-2"].hidden = true
technologies["speed-module-2"].hidden_in_factoriopedia = true
technologies["speed-module-3"].hidden = true
technologies["speed-module-3"].hidden_in_factoriopedia = true
technologies["spidertron"].hidden = true
technologies["spidertron"].hidden_in_factoriopedia = true
technologies["steam-power"].hidden = true
technologies["steam-power"].hidden_in_factoriopedia = true
technologies["steel-axe"].hidden = true
technologies["steel-axe"].hidden_in_factoriopedia = true
technologies["steel-processing"].hidden = true
technologies["steel-processing"].hidden_in_factoriopedia = true
technologies["stone-wall"].hidden = true
technologies["stone-wall"].hidden_in_factoriopedia = true
technologies["stronger-explosives-1"].hidden = true
technologies["stronger-explosives-1"].hidden_in_factoriopedia = true
technologies["stronger-explosives-2"].hidden = true
technologies["stronger-explosives-2"].hidden_in_factoriopedia = true
technologies["stronger-explosives-3"].hidden = true
technologies["stronger-explosives-3"].hidden_in_factoriopedia = true
technologies["stronger-explosives-4"].hidden = true
technologies["stronger-explosives-4"].hidden_in_factoriopedia = true
technologies["stronger-explosives-5"].hidden = true
technologies["stronger-explosives-5"].hidden_in_factoriopedia = true
technologies["stronger-explosives-6"].hidden = true
technologies["stronger-explosives-6"].hidden_in_factoriopedia = true
technologies["sulfur-processing"].hidden = true
technologies["sulfur-processing"].hidden_in_factoriopedia = true
technologies["tank"].hidden = true
technologies["tank"].hidden_in_factoriopedia = true
technologies["toolbelt"].hidden = true
technologies["toolbelt"].hidden_in_factoriopedia = true
technologies["uranium-ammo"].hidden = true
technologies["uranium-ammo"].hidden_in_factoriopedia = true
technologies["uranium-mining"].hidden = true
technologies["uranium-mining"].hidden_in_factoriopedia = true
technologies["uranium-processing"].hidden = true
technologies["uranium-processing"].hidden_in_factoriopedia = true
technologies["utility-science-pack"].hidden = true
technologies["utility-science-pack"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-1"].hidden = true
technologies["weapon-shooting-speed-1"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-2"].hidden = true
technologies["weapon-shooting-speed-2"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-3"].hidden = true
technologies["weapon-shooting-speed-3"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-4"].hidden = true
technologies["weapon-shooting-speed-4"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-5"].hidden = true
technologies["weapon-shooting-speed-5"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-6"].hidden = true
technologies["weapon-shooting-speed-6"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-1"].hidden = true
technologies["worker-robots-speed-1"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-2"].hidden = true
technologies["worker-robots-speed-2"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-3"].hidden = true
technologies["worker-robots-speed-3"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-4"].hidden = true
technologies["worker-robots-speed-4"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-5"].hidden = true
technologies["worker-robots-speed-5"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-1"].hidden = true
technologies["worker-robots-storage-1"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-2"].hidden = true
technologies["worker-robots-storage-2"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-3"].hidden = true
technologies["worker-robots-storage-3"].hidden_in_factoriopedia = true

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136529-"
new_tree_copy.unit.count = 215
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132856-"
new_tree_copy.unit.count = 404
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132744-"
new_tree_copy.unit.count = 354
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133986-"
new_tree_copy.unit.count = 465
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133655-"
new_tree_copy.unit.count = 298
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fluid-handling")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131537-"
new_tree_copy.unit.count = 221
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134750-"
new_tree_copy.unit.count = 356
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135796-"
new_tree_copy.unit.count = 375
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "personal-roboport-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133936-"
new_tree_copy.unit.count = 457
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132311-"
new_tree_copy.unit.count = 95
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "artillery")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133383-"
new_tree_copy.unit.count = 163
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "personal-roboport-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136305-"
new_tree_copy.unit.count = 94
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "gun-turret")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133618-"
new_tree_copy.unit.count = 280
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132709-"
new_tree_copy.unit.count = 327
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "artillery")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135217-"
new_tree_copy.unit.count = 45
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "battery")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134692-"
new_tree_copy.unit.count = 321
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "rocket-fuel")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136100-"
new_tree_copy.unit.count = 13
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133523-"
new_tree_copy.unit.count = 209
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132325-"
new_tree_copy.unit.count = 107
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "land-mine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133653-"
new_tree_copy.unit.count = 297
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131593-"
new_tree_copy.unit.count = 271
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134508-"
new_tree_copy.unit.count = 200
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133677-"
new_tree_copy.unit.count = 303
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-axe")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134349-"
new_tree_copy.unit.count = 131
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131938-"
new_tree_copy.unit.count = 457
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133812-"
new_tree_copy.unit.count = 380
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135563-"
new_tree_copy.unit.count = 233
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "repair-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132359-"
new_tree_copy.unit.count = 137
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136314-"
new_tree_copy.unit.count = 102
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136168-"
new_tree_copy.unit.count = 21
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "landfill")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134177-"
new_tree_copy.unit.count = 25
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133407-"
new_tree_copy.unit.count = 181
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135326-"
new_tree_copy.unit.count = 107
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132361-"
new_tree_copy.unit.count = 138
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133872-"
new_tree_copy.unit.count = 427
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134176-"
new_tree_copy.unit.count = 22
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "battery-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132266-"
new_tree_copy.unit.count = 69
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "circuit-network")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134677-"
new_tree_copy.unit.count = 304
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136277-"
new_tree_copy.unit.count = 79
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135710-"
new_tree_copy.unit.count = 330
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132376-"
new_tree_copy.unit.count = 148
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131882-"
new_tree_copy.unit.count = 430
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133376-"
new_tree_copy.unit.count = 158
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133795-"
new_tree_copy.unit.count = 375
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "advanced-material-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133808-"
new_tree_copy.unit.count = 379
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132461-"
new_tree_copy.unit.count = 193
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "engine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133875-"
new_tree_copy.unit.count = 430
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135051-"
new_tree_copy.unit.count = 489
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131895-"
new_tree_copy.unit.count = 435
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133514-"
new_tree_copy.unit.count = 205
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136855-"
new_tree_copy.unit.count = 406
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132482-"
new_tree_copy.unit.count = 193
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "uranium-mining")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134709-"
new_tree_copy.unit.count = 329
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "electric-energy-distribution-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131796-"
new_tree_copy.unit.count = 375
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135386-"
new_tree_copy.unit.count = 163
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "discharge-defense-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136253-"
new_tree_copy.unit.count = 58
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134811-"
new_tree_copy.unit.count = 387
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133688-"
new_tree_copy.unit.count = 317
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "discharge-defense-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131753-"
new_tree_copy.unit.count = 360
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133686-"
new_tree_copy.unit.count = 306
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131889-"
new_tree_copy.unit.count = 431
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135318-"
new_tree_copy.unit.count = 106
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135899-"
new_tree_copy.unit.count = 440
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131905-"
new_tree_copy.unit.count = 448
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136710-"
new_tree_copy.unit.count = 333
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133819-"
new_tree_copy.unit.count = 393
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132490-"
new_tree_copy.unit.count = 198
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134801-"
new_tree_copy.unit.count = 376
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136274-"
new_tree_copy.unit.count = 78
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135893-"
new_tree_copy.unit.count = 435
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136240-"
new_tree_copy.unit.count = 48
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-axe")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132319-"
new_tree_copy.unit.count = 103
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "plastics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134646-"
new_tree_copy.unit.count = 296
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133444-"
new_tree_copy.unit.count = 190
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133977-"
new_tree_copy.unit.count = 464
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fluid-handling")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131624-"
new_tree_copy.unit.count = 280
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133858-"
new_tree_copy.unit.count = 417
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135809-"
new_tree_copy.unit.count = 380
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135008-"
new_tree_copy.unit.count = 475
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131080-"
new_tree_copy.unit.count = 6
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132095-"
new_tree_copy.unit.count = 8
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "repair-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131737-"
new_tree_copy.unit.count = 351
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133565-"
new_tree_copy.unit.count = 236
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "land-mine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134303-"
new_tree_copy.unit.count = 92
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fluid-handling")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133174-"
new_tree_copy.unit.count = 21
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133865-"
new_tree_copy.unit.count = 424
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "personal-laser-defense-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136899-"
new_tree_copy.unit.count = 442
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "gun-turret")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134294-"
new_tree_copy.unit.count = 87
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "low-density-structure")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136026-"
new_tree_copy.unit.count = 479
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134035-"
new_tree_copy.unit.count = 480
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136284-"
new_tree_copy.unit.count = 80
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "night-vision-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132803-"
new_tree_copy.unit.count = 377
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135534-"
new_tree_copy.unit.count = 222
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134831-"
new_tree_copy.unit.count = 393
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136545-"
new_tree_copy.unit.count = 222
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132126-"
new_tree_copy.unit.count = 15
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "cliff-explosives")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136600-"
new_tree_copy.unit.count = 274
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "advanced-combinators")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135416-"
new_tree_copy.unit.count = 187
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134083-"
new_tree_copy.unit.count = 7
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132865-"
new_tree_copy.unit.count = 419
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134917-"
new_tree_copy.unit.count = 453
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133552-"
new_tree_copy.unit.count = 226
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133404-"
new_tree_copy.unit.count = 170
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134315-"
new_tree_copy.unit.count = 101
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135849-"
new_tree_copy.unit.count = 403
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136642-"
new_tree_copy.unit.count = 292
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134261-"
new_tree_copy.unit.count = 63
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stone-wall")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136843-"
new_tree_copy.unit.count = 400
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136474-"
new_tree_copy.unit.count = 193
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134208-"
new_tree_copy.unit.count = 38
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134725-"
new_tree_copy.unit.count = 348
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133449-"
new_tree_copy.unit.count = 193
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136574-"
new_tree_copy.unit.count = 267
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132059-"
new_tree_copy.unit.count = 490
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133561-"
new_tree_copy.unit.count = 232
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134999-"
new_tree_copy.unit.count = 469
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135904-"
new_tree_copy.unit.count = 451
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134730-"
new_tree_copy.unit.count = 350
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134913-"
new_tree_copy.unit.count = 453
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135501-"
new_tree_copy.unit.count = 199
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131698-"
new_tree_copy.unit.count = 327
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133213-"
new_tree_copy.unit.count = 41
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132953-"
new_tree_copy.unit.count = 461
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "solar-energy")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132440-"
new_tree_copy.unit.count = 189
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135147-"
new_tree_copy.unit.count = 20
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132646-"
new_tree_copy.unit.count = 296
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131298-"
new_tree_copy.unit.count = 88
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134029-"
new_tree_copy.unit.count = 480
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "circuit-network")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135168-"
new_tree_copy.unit.count = 20
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135780-"
new_tree_copy.unit.count = 369
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fission-reactor-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135373-"
new_tree_copy.unit.count = 157
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132368-"
new_tree_copy.unit.count = 144
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "uranium-ammo")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133196-"
new_tree_copy.unit.count = 30
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135896-"
new_tree_copy.unit.count = 440
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-system")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134760-"
new_tree_copy.unit.count = 360
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133342-"
new_tree_copy.unit.count = 119
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133041-"
new_tree_copy.unit.count = 484
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134954-"
new_tree_copy.unit.count = 461
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136258-"
new_tree_copy.unit.count = 61
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136038-"
new_tree_copy.unit.count = 486
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "energy-shield-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136483-"
new_tree_copy.unit.count = 197
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "exoskeleton-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134388-"
new_tree_copy.unit.count = 165
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "explosives")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135310-"
new_tree_copy.unit.count = 96
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "cliff-explosives")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134838-"
new_tree_copy.unit.count = 396
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131215-"
new_tree_copy.unit.count = 10
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131962-"
new_tree_copy.unit.count = 462
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "personal-roboport-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135003-"
new_tree_copy.unit.count = 470
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133572-"
new_tree_copy.unit.count = 266
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "electric-energy-distribution-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135012-"
new_tree_copy.unit.count = 478
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135348-"
new_tree_copy.unit.count = 135
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "lamp")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136975-"
new_tree_copy.unit.count = 464
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "rocket-silo")
table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 1: flamethrower-turret"})

table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 2: heat-exchanger"})

table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 3: steam-turbine"})

data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136209-"
new_tree_copy.unit.count = 40
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136603-"
new_tree_copy.unit.count = 276
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135332-"
new_tree_copy.unit.count = 110
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134564-"
new_tree_copy.unit.count = 238
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "advanced-circuit")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131415-"
new_tree_copy.unit.count = 184
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133249-"
new_tree_copy.unit.count = 57
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132113-"
new_tree_copy.unit.count = 14
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "oil-gathering")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132087-"
new_tree_copy.unit.count = 7
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136060-"
new_tree_copy.unit.count = 495
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131715-"
new_tree_copy.unit.count = 333
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136247-"
new_tree_copy.unit.count = 58
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131578-"
new_tree_copy.unit.count = 266
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135932-"
new_tree_copy.unit.count = 454
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135220-"
new_tree_copy.unit.count = 46
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134080-"
new_tree_copy.unit.count = 7
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133178-"
new_tree_copy.unit.count = 26
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136524-"
new_tree_copy.unit.count = 211
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131817-"
new_tree_copy.unit.count = 390
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133730-"
new_tree_copy.unit.count = 348
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134986-"
new_tree_copy.unit.count = 468
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135565-"
new_tree_copy.unit.count = 248
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132147-"
new_tree_copy.unit.count = 17
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "electric-energy-distribution-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131632-"
new_tree_copy.unit.count = 287
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135396-"
new_tree_copy.unit.count = 169
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131569-"
new_tree_copy.unit.count = 255
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133583-"
new_tree_copy.unit.count = 268
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "processing-unit")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132135-"
new_tree_copy.unit.count = 17
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135479-"
new_tree_copy.unit.count = 196
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

